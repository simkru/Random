﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class LevelManager : Singleton<LevelManager>
{
	//A prefab for creating a single tile
	[SerializeField]
	private GameObject[] tilePrefabs;

	[SerializeField]
	private CameraMovement cameraMovement;

	private Point blueSpawn, orangeSpawn;

	[SerializeField]
	private GameObject bluePortalPrefab;
	[SerializeField]
	private GameObject orangePortalPrefab;

	public Dictionary<Point, TileScript> Tiles { get; set; }

	//A property for returning the size of a tile
	public float TileSize
	{
		get { return tilePrefabs[0].GetComponent<SpriteRenderer>().sprite.bounds.size.x; }
	}

	// Use this for initialization
	void Start ()
	{
		CreateLevel();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	// Creates our level
	private void CreateLevel()
	{
		Tiles = new Dictionary<Point, TileScript>();

		string[] mapData = ReadLevelText();

		// Calculates the x map size
		int mapX = mapData[0].ToCharArray().Length;

		// Calculates the y map size
		int mapY = mapData.Length;

		Vector3 maxTile = Vector3.zero;

		// Calculates the world start point, this is the top left corner of the screen
		Vector3 worldStart = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height));

		for(int y = 0; y < mapY; y++)	// The y positions
		{
			char[] newTiles = mapData[y].ToCharArray(); // Gets all the tiles, that we need to place
			for(int x = 0; x < mapX; x++)	// The x positions
			{
				PlaceTile(newTiles[x].ToString(), x, y, worldStart);
			}
		}

		maxTile = Tiles[new Point(mapX - 1, mapY - 1)].transform.position;

		cameraMovement.SetLimits(new Vector3(maxTile.x + TileSize, maxTile.y - TileSize));
		SpawnPortals();
	}

	// tileType - The type of tile to place
	// x - x position of the tile
	// y - y position of the tile
	// worldStart - The world start position
	private void PlaceTile(string tileType, int x, int y, Vector3 worldStart)
	{
		// Parses the tiletype to an ont, so that we can use it as an indexer when we create a new tile
		int tileIndex = int.Parse(tileType);

		// Creates a new tile and makes a reference to that tile in the newTile variable
		TileScript newTile = Instantiate(tilePrefabs[tileIndex]).GetComponent<TileScript>();

		// Uses the new tile variable to change the position of the tile
		newTile.Setup(new Point(x, y), new Vector3(worldStart.x + (TileSize * x), worldStart.y - (TileSize * y), 0));

		
	}

	private string[] ReadLevelText()
	{
		TextAsset bindData = Resources.Load("Level") as TextAsset;

		string data = bindData.text.Replace(Environment.NewLine, string.Empty);

		return data.Split('-');
	}

	private void SpawnPortals()
	{
		blueSpawn = new Point(0, 0);

		Instantiate(bluePortalPrefab, Tiles[blueSpawn].GetComponent<TileScript>().WorldPosition, Quaternion.identity);

		orangeSpawn = new Point(11, 6);

		Instantiate(orangePortalPrefab, Tiles[orangeSpawn].GetComponent<TileScript>().WorldPosition, Quaternion.identity);

	}
}
