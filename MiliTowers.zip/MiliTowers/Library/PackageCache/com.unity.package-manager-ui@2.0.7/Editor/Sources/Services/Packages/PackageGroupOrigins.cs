﻿namespace UnityEditor.PackageManager.UI
{
    internal enum PackageGroupOrigins
    {
        Packages,
        BuiltInPackages
    }
}